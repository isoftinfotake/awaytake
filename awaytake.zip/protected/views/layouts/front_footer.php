<?php 
/*add global variables to footer*/
ScriptManager::registerGlobalVariables();
?>
<script src="//www.google.com/recaptcha/api.js?onload=onloadMyCallback&render=explicit" async defer ></script>
</body>
</html>