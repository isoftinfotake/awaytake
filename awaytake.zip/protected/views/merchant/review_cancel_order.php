<div class="review_cancel_pop_wrap">

<h3 class="center"><?php echo t("Review order")?></h3>

<div class="mytable">
	<div class="col">
	<a href="javascript:;" data-id="<?php echo $order_id?>" class="request_cancel_approved"><?php echo t("Approved")?></a>
	</div>
	
	<div class="col">
	<a href="javascript:;" data-id="<?php echo $order_id?>" class="request_cancel_decline"><?php echo t("Decline")?></a>
	</div>

</div> <!--mytable-->

</div>