<div class="parallax-search" 
data-parallax="scroll" data-position="top" data-bleed="0" 
data-image-src="<?php echo assetsURL()."/images/b-4.jpg"?>">

<div class="search-wraps">	
	<p></p>
</div> <!--search-wraps-->

</div> <!--parallax-container-->

<div class="sections">
   <div class="container center" style="min-height:200px;padding-top:40px;">
      <h3 class="text-success"><?php echo isset($data)?$data:''?></h3>
   </div>
</div>