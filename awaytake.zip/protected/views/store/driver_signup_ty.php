<?php
$this->renderPartial('/front/banner-receipt',array(
   'h1'=>t("Driver Signup"),
   'sub_text'=>t("Thank You for signing up")
));
?>

<div class="sections section-grey">

  <div class="container">
   
   
  
  </div>
  
</div>  