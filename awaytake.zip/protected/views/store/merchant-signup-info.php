     <link href="<?php echo Yii::app()->createUrl('assets/css/merchantsignupinfo.css');?>" rel="stylesheet" />
       <script src="<?php echo Yii::app()->createUrl('assets/js/jquery.min3.js');?>"></script>

	 <script src="<?php echo Yii::app()->createUrl('assets/js/jquery.min2.js');?>"></script>
  <style>
        .join-btn-secondary {
    border: 1px solid #fff !important;
        display: inline-block !important;
}
        #menu li {
   
    margin: 2px;

}
 
 .listyourrestaurant{
          display:none !important;
      }
   .rest_brow, .rest_home{display: none !important;}

    
    .rest_home{
    display: none !important;
    }
        .rest_brow{
    display: none !important;
    }
    
  .join-btn-secondary{
        border: 1px solid #fff !important; 
    }
#menu li.active a, #menu a:hover, .section-footer a:hover, .mobile-search-menu a.selected i, .progress-dot a.selected i {
    color: #fff !important;
}

.intl-tel-input .flag-dropdown {
 
    height: 30px;
}
.iti-flag{width:16px;height:11px;background:url(<?php echo Yii::app()->createUrl('assets/img/flags.png');?>)}.intl-tel-input{position:relative;display:inline-block}.intl-tel-input *{box-sizing:border-box;-moz-box-sizing:border-box}.intl-tel-input .hide{display:none}.intl-tel-input .v-hide{visibility:hidden}.intl-tel-input input,.intl-tel-input input[type=tel],.intl-tel-input input[type=text]{position:relative;z-index:0;margin-top:0!important;margin-bottom:0!important;padding-left:44px;margin-left:0;transition:background-color .1s ease-out}.intl-tel-input input.iti-invalid-key{transition:background-color 0;background-color:#FFC7C7}.intl-tel-input .flag-dropdown{position:absolute;top:0;bottom:0;padding:1px}.intl-tel-input .flag-dropdown:hover{cursor:pointer}.intl-tel-input .flag-dropdown:hover .selected-flag{background-color:rgba(0,0,0,.05)}.intl-tel-input input[disabled]+.flag-dropdown:hover,.intl-tel-input input[readonly]+.flag-dropdown:hover{cursor:default}.intl-tel-input input[disabled]+.flag-dropdown:hover .selected-flag,.intl-tel-input input[readonly]+.flag-dropdown:hover .selected-flag{background-color:transparent}.intl-tel-input .selected-flag{z-index:1;position:relative;width:38px;height:100%;padding:0 0 0 8px}.intl-tel-input .selected-flag .iti-flag{position:absolute;top:50%;margin-top:-5px}.intl-tel-input .selected-flag .arrow{position:relative;top:50%;margin-top:-2px;left:20px;width:0;height:0;border-left:3px solid transparent;border-right:3px solid transparent;border-top:4px solid #555}.intl-tel-input .selected-flag .arrow.up{border-top:none;border-bottom:4px solid #555}.intl-tel-input .country-list{list-style:none;position:absolute;z-index:2;padding:0;margin:0 0 0 -1px;box-shadow:1px 1px 4px rgba(0,0,0,.2);background-color:#fff;border:1px solid #CCC;width:430px;max-height:200px;overflow-y:scroll}.intl-tel-input .country-list .iti-flag{display:inline-block}.intl-tel-input .country-list .divider{padding-bottom:5px;margin-bottom:5px;border-bottom:1px solid #CCC}.intl-tel-input .country-list .country{padding:5px 10px}.intl-tel-input .country-list .country .dial-code{color:#999}.intl-tel-input .country-list .country.highlight{background-color:rgba(0,0,0,.05)}.intl-tel-input .country-list .country-name,.intl-tel-input .country-list .iti-flag{margin-right:6px}

#ifYes{
/*	margin : 0px !important;
	padding : -5px !important;
	max-width : 354px !Important;*/
}


</style>
<script type="text/javascript">
$( document ).ready(function() {
$('#restaurant_phone').click(function(){
   $(".ifYes9").css("visibility", "visible"); 
    $(".ifYes9").css("margin-top", "10px"); 
     $(".ifYes9").css("height", "auto"); 
      $(".ifYes9").css("overflow", "visible");
           $(".ifYes9").css("margin-bottom", "20px");
})
 
});

function show1(){
  
  document.getElementById('ifYes').style.display ='block';
  document.getElementById('ifYes1').style.display ='block';
  document.getElementById('ifYes2').style.display ='block';
  document.getElementById('ifYes3').style.display ='block';
  document.getElementById('ifYes4').style.display ='block';
  document.getElementById('ifYes5').style.display ='block';
  document.getElementById('ifYes6').style.display ='block';
  document.getElementById('ifYes7').style.display ='block';
  document.getElementById('ifYes8').style.display ='block';
  document.getElementById('ifYes10').style.display ='block';
  document.getElementById('ifYes11').style.display ='block';
  document.getElementById('ifYes12').style.display ='block';
  document.getElementById('ifYes13').style.display ='block';
  document.getElementById('ifYes14').style.display ='block';
  document.getElementById('cuisine_chosen').style.display ='block';


}

</script>
<!--second form start-->
                  <div id="second-form-div">
                     <form class="forms signup-access" id="forms" onsubmit="return false;">
                          <h4 class="join-medium" style="margin-top: 0;">
    List Your Restaurants
  </h4>
           
                         
                        <?php echo CHtml::hiddenField('action','merchantSignUp2')?>
                        <?php echo CHtml::hiddenField('currentController','store')?>	 
                        <?php FunctionsV3::addCsrfToken();?>
                        <div class="row top10">
                            <label for="ultranet_label_input_0"><?php echo t("Restaurant Name")?></label>
                           <div class="col-md-12 ">
                              <?php echo CHtml::textField('restaurant_name',
                                 isset($data['restaurant_name'])?$data['restaurant_name']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required",
                               ))?>
                           </div>
                        </div>
                        <?php if ( getOptionA('merchant_reg_abn')=="yes"):?>
                        <div class="row top10">
                            <label for="ultranet_label_input_0"><?php echo t("ABN")?></label>
                           <div class="col-md-12 ">
                              <?php echo CHtml::textField('abn',
                                 isset($data['restaurant_name'])?$data['abn']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>
                           </div>
                        </div>
                        <?php endif;?>      
                        <div class="row top10">
                           <label for="ultranet_label_input_0"><?php echo t("Restaurant Phone")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('restaurant_phone',
                                 isset($data['restaurant_phone'])?$data['restaurant_phone']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'onclick'=>"show1()"
                                 ))?>    
                           </div>
                        </div>
                      
                       
                        <div class="row top10" id="ifYes" style="display:none;">
                            <label for="ultranet_label_input_0"><?php echo t("Contact Name")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('contact_name',
                                 isset($data['contact_name'])?$data['contact_name']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes1" style="display:none;">
                            <label for="ultranet_label_input_0"><?php echo t("Contact Phone")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('contact_phone',
                                 isset($data['contact_phone'])?$data['contact_phone']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required",
                                  'id'=>'telephone'
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes2" style="display:none;">
                          <label for="ultranet_label_input_0"><?php echo t("Contact Email")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('contact_email',
                                 isset($data['contact_email'])?$data['contact_email']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"email"
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes3" style="display:none;">
                           <div class="col-md-12"></div>
                           <div class="col-md-12">
                              <p class="text-muted text-small"><?php echo t("Important: Please enter your correct email. we will sent an activation code to your email")?></p>
                           </div>
                        </div>
                        <div class="row top10" id="ifYes4" style="display:none;">
                            <label for="ultranet_label_input_0"><?php echo t("Street Address")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('street',
                                 isset($data['street'])?$data['street']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes5" style="display:none;">
                            <label for="ultranet_label_input_0"><?php echo t("City")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('city',
                                 isset($data['city'])?$data['city']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes6" style="display:none;">
                            <label for="ultranet_label_input_0"><?php echo t("Post Code/Zip Code")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('post_code',
                                 isset($data['post_code'])?$data['post_code']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes7" style="display:none;">
                           <label for="ultranet_label_input_0"><?php echo t("Country")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::dropDownList('country_code',
                                 getOptionA('merchant_default_country'),
                                 (array)Yii::app()->functions->CountryListMerchant(),          
                                 array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes8" style="display:none;">
                            <label for="ultranet_label_input_0"><?php echo t("State/Region")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('state',
                                 isset($data['state'])?$data['state']:""
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                <div class="row top10 ifYes9" style="    visibility: hidden;
    margin-top: 0px;
    height: 0px;
    overflow: hidden;">
                            <label for="ultranet_label_input_0"><?php echo t("Cuisine")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::dropDownList('cuisine[]',
                                 isset($data['cuisine'])?(array)json_decode($data['cuisine']):"",
                                 (array)Yii::app()->functions->Cuisine(true),          
                                 array(
                                 'class'=>'full-width chosen',
                                 'multiple'=>true,
                                 'data-validation'=>"required"  
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes10" style="display:none;">
                            <label for="ultranet_label_input_0"><?php echo t("Services Pick Up or Delivery?")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::dropDownList('service',
                                 isset($data['service'])?$data['service']:"",
                                 (array)Yii::app()->functions->Services(),          
                                 array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                     <!--   <div class="top15">
                           <?php FunctionsV3::sectionHeader('Commission Type');?>
                        </div>
                        <div class="row top10">
                           <div class="col-md-12"><?php echo t("Type")?></div>
                           <div class="col-md-12">
                              <?php
                                 echo CHtml::dropDownList('merchant_type','',
                                 (array)$commission_type,array(
                                   'class'=>'grey-fields full-width merchant_type_selection',
                                   'data-validation'=>"required"
                                 ))
                                 ?>           
                           </div>
                        </div>
                        <div class="row top10 invoice_terms_wrap">
                           <div class="col-md-12"><?php echo t("Invoice Terms")?></div>
                           <div class="col-md-12">
                              <?php
                                 echo CHtml::dropDownList('invoice_terms','',
                                 (array)FunctionsV3::InvoiceTerms(),array(
                                   'class'=>'grey-fields full-width',
                                   'data-validation'=>"required"
                                 ))
                                 ?>           
                           </div>
                        </div>-->
                        <div class="top15" id="ifYes11" style="display:none;">
                           <?php FunctionsV3::sectionHeader('Login Information');?>
                        </div>
                        <div class="row top10" id="ifYes" style="display:none;">
                            <label for="ultranet_label_input_0"><?php echo t("Username")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::textField('username',
                                 ''
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>
                           </div>
                        </div>
                        <div class="row top10" id="ifYes12" style="display:none;">
                           <label for="ultranet_label_input_0"><?php echo t("Password")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::passwordField('password',
                                 ''
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                        <div class="row top10" id="ifYes13" style="display:none;">
                           <label for="ultranet_label_input_0"><?php echo t("Confirm Password")?></label>
                           <div class="col-md-12">
                              <?php echo CHtml::passwordField('cpassword',
                                 ''
                                 ,array(
                                 'class'=>'grey-fields full-width',
                                 'data-validation'=>"required"
                                 ))?>           
                           </div>
                        </div>
                        <?php if ( $terms_merchant=="yes"):?>
                        <?php $terms_link=Yii::app()->functions->prettyLink($terms_merchant_url);?>
                        <div class="row top10" id="ifYes14" style="display:none;">
                           <div class="col-md-12"></div>
                           <div class="col-md-12">
                              <?php 
                                 echo CHtml::checkBox('terms_n_condition',false,array(
                                  'value'=>2,
                                  'class'=>"",
                                  'data-validation'=>"required"
                                 ));
                                 echo " ". t("I Agree To")." <a href=\"$terms_link\" target=\"_blank\">".t("The Terms & Conditions")."</a>";
                                 ?>  
                           </div>
                        </div>
                        <?php endif;?>
                        <?php if ($kapcha_enabled==2):?>      
                        <div class="top10 capcha-wrapper">
                           <div id="kapcha-1"></div>
                        </div>
                        <?php endif;?>
                        
                       
                        
                        <div class="get-started-button">
                              <input type="submit" value="<?php echo t("List Your Restaurant")?>" class="join-btn join-btn--wide join-btn--large join-save-button js-join-save-button-no-user-data">
                        </div>
                     </form>
					 <div class="clearfix"></div>
                     <div class="form-tabs form-tabs--inline">
                        <div data-toggle-show="new-registration-form" id="new-registration-tab" class="js-form-tabs__tab
                           js-form-tabs__tab--inverse
                           form-tabs__block-tab
                           ">
                           <p class="join-regular form-tabs__block-tab-title">
                              Want to create a new listing?
                           </p>
                           <button class=" form-tabs__button ">
                           Create new listing
                           </button>
                        </div>
                        <div data-toggle-show="proceed-registration-form" id="proceed-registration-tab" class="js-form-tabs__tab
                           js-form-tabs__tab--inverse
                           form-tabs__block-tab
                           active
                           ">
                           <p class="join-regular form-tabs__block-tab-title">
                              Already started a registration?
                           </p>
                           <button class="button2  form-tabs__button">
                         Continue your registration
                           </button>
                        </div>
                     </div>
                  </div>
                  <!--second form end-->


<div class="join-section join-section--blue-contrast" 	>
   <div class="join-content-layout">
      <div class="col-md-12 join-hero-container-cell">
         <div class="join-hero-container" >
            <div class="join-hero-container__text" style="vertical-align: middle;">
               <h1 class="join-xlarge
                  join-headline
                  join-h1
                  bui_color_white
                  join-tablet-centered
                  js-join-animated-header-container">
                                          <div class="js-join-animated-header" style="display:none;">
List your 
<div class="join-animated-header-property-type-container js-join-animated-header-property-type">
<p class="join-animated-header-property-type">
Restaurants
</p>
<p class="join-animated-header-property-type">
On
</p>
<p class="join-animated-header-property-type">
awaytake
</p>
<p class="join-animated-header-property-type">
Let People Looking For Food Around Find Your Restaurant
</p>

</div>
</div>


                    <div class="js-join-animated-header-list-anything" style="display: block;">
                            List Your<div class="join-animated-header-property-type-container" style="color: #12b512;"><p class="join-animated-header-property-type"></p>Restaurant</div>  On <span style="color: #12b512;display: inline-block;">Away</span><span style="color: #d6d609;display: inline-block;">Take</span>
                        </div>
                      </h1>
                        <h3 class="join-medium
                                   join-h3-new-form
                                   join-h3-subtitle">
                          Let People Looking For Food Around Find Your Restaurant

                        </h3>
            </div>
            <div class="join-hero-container__form">
               <div class="join-section__registration-form join-section__registration-form--white js-join-highlight-form" style="margin: auto; position: relative; z-index: 1;">
                  
				  
				  
				  
				  <!--first form start-->
                  <div id="main-form-div" >
                     <div id="new-registration-form" class="join-section__form-container js-form-container" style="">
                      
                        <form onsubmit="return false;" method="POST" class="frm-resume-signup uk-form has-validation-callback js-signup-scroll
             signup-access" id="frm-resume-signup" style="display:block;">
       <h4 class="join-medium" style="margin-top: 0;">
   Continue Your Registration
  </h4>
      <input type="hidden" id="action" name="action" value="merchantResumeSignup">
      <input type="hidden" id="do-action" name="do-action" value="sigin">         
      <?php echo CHtml::hiddenField('currentController','store')?>  
      
      
	   <div class="row top10 input-validation">	
	     <label for="ultranet_label_input_0">Restaurant Email</label>

		  <div class="col-md-12">
		  <?php echo CHtml::textField('contact_email','',array(
		    'data-validation'=>'required',		    
		    'class'=>'grey-fields full-width',
		 
		  ))?>
		  </div>
		</div>
			  <!-- <div class="row top10 input-validation">	
	     <label for="ultranet_label_input_0">Restaurant Phone</label>

		  <div class="col-md-12">
		  <?php echo CHtml::textField('restaurant_phone','',array(
		    'data-validation'=>'required',		    
		    'class'=>'grey-fields full-width',
		    
		  ))?>
		  </div>
		</div>-->
		<div class="row top10">	
		<div class="col-md-12">
		  <input type="submit" class="join-btn
                               join-btn--wide
                               join-btn--large
                               join-save-button
                               js-join-save-button-no-user-data" value="<?php echo Yii::t("default","Get Your Registration Link")?>">
		</div>
		</div>
      
      </form>
                     </div>
                     <div class="clearfix"></div>
                     <div class="form-tabs form-tabs--inline">
                        <div data-toggle-show="new-registration-form" id="new-registration-tab" class="js-form-tabs__tab
                           js-form-tabs__tab--inverse
                           form-tabs__block-tab
                           ">
                           <p class="join-regular form-tabs__block-tab-title">
                              Want to create a new listing?
                           </p>
                           <button class="
                              form-tabs__button
                              ">
                           Create new listing
                           </button>
                        </div>
                        <div data-toggle-show="proceed-registration-form" id="proceed-registration-tab" class="js-form-tabs__tab
                           js-form-tabs__tab--inverse
                           form-tabs__block-tab
                           active
                           ">
                           <p class="join-regular form-tabs__block-tab-title">
                             Want to create a new listing?
                           </p>
                           <button class="form-tabs__button button1">
                           Create new listing
                           </button>
                        </div>
                     </div>
                  </div>
                  <!--first form end-->
                  
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<div class="join-section join-section--bordered js-join-global-scroll join-section--no-padding" style="float: none;">
   <div class="join-content-layout js-join-global-scroll--page join-global-scroll-content-section--visible" style="">
      <div class="join-table-layout text-center join-global-scroll-content js-join-global-scroll-page-content" id="more-than-just-a-listing" style="">
         <div class="join-table-layout__cell" style="width: 100%;">
            <h4 class="join-xlarge">
               Marketing And Promotion
            </h4>
         </div>
      </div>
   </div>
   <div class="join-content-layout js-join-global-scroll--page join-content-layout1" style="height: 469.5px;">
      <div class="join-table-layout join-global-scroll-content js-join-global-scroll-page-content" style="height: 469.5px;">
         <div class="join-table-layout__cell" style="text-align: center;">
            <img src="<?php echo Yii::app()->createUrl('/upload/location-based-food-comparison.png');?>" class="uk-thumbnail" id="logo-small">
         </div>
         <div class="join-table-layout__cell">
            <h4 class="join-xlarge">
               Location Based Food Comparison
            </h4>
            <p class="join-medium">
               That's why we don't wait for guests to come to us, but actively promote your property on search engines all across the globe.
            </p>
         </div>
      </div>
   </div>
   <div class="join-content-layout js-join-global-scroll--page join-content-layout1" style="height: 469.5px;">
      <div class="join-table-layout join-global-scroll-content js-join-global-scroll-page-content" style="height: 469.5px;">
         <div class="join-table-layout__cell" style="text-align: center;">
            <img src="<?php echo Yii::app()->createUrl('/upload/navigatetothe-cheapest-food.png');?>" class="uk-thumbnail" id="logo-small">
         </div>
         <div class="join-table-layout__cell">
            <h4 class="join-xlarge">
             Navigate to the Cheapest Food
            </h4>
            <p class="join-medium">
               So a listing on Booking.com means your listing is advertised on Google Maps too.
            </p>
         </div>
      </div>
   </div>
   <div class="join-content-layout js-join-global-scroll--page bottom-divs join-content-layout1" style="height: 509.5px; ">
      <div class="join-table-layout join-global-scroll-content js-join-global-scroll-page-content" style="height: 469.5px;" >
         <div class="join-table-layout__cell" style="text-align: center;">
            <img src="<?php echo Yii::app()->createUrl('/upload/LocationBasedPromotionalPushNotifications.png');?>" class="uk-thumbnail" id="logo-small">
         </div>
         <div class="join-table-layout__cell ">
            <h4 class="join-xlarge join-table-layout__cell1">
               Location Based Promotional Push Notifications
            </h4>
            <p class="join-medium">
               We partner with airline companies such as Emirates, American Airlines, easyJet, KLM and much more to promote your property to their customers.
            </p>
         </div>
      </div>
   </div>
   
</div>
<style>
@media (max-width: 992px){

}


@media only screen and (max-width: 320px){
.top-menu-wrapper img.logo-desktop {
   display:none !important;
}
#menu{
    
    margin-top: 2px !important;
}
.restaurant_panel{
    display:none !important;
}
.language-selection {
    margin: 2px 47px !important;
    float: left !important;
}
.continueyourregistration {
    margin-right: -25px !important;
       width: 64% !important;
    float: right !important;
    margin-top: -37px !important;
      text-align: center;
}
.continueyourregistration span {
    font-size: 9px !important;
}
.logo {
    width: 88px !important;
    padding-top: 5px !important;
    margin-left: -31px !important;
}

}
@media only screen and (max-width: 1024px){
    .join-section--blue-contrast {
    padding: 0px 0 !important;
    height: 557px;
}
  .join-content-layout1 {
    margin-top: -1px !important; 
}
.top-menu-wrapper .col-b, .parallax-mirror, .logo-desktop, .search-left-content, .search-view-map, .menu-right-content, #change-package-wrap, #section-social-login {
    display: block !important;
}
.top-menu-wrapper {
   
    background: #001b42 !important;
}
  .top-menu-wrapper img.logo-desktop {
   display:none !important;
}
.menu-nav-mobile, .cart-mobile-handle {
    display:none !important;
}
.logo {
    width: 88px;
    padding-top: 5px;
    margin-left: 0px;
    height: 43px;
}
#menu{
    
    margin-top: -8px;
}
 .restaurant_panel{
    display:none !important;
}
.continueyourregistration {
      margin-right: 0px !important;
    width: 50% !important;
    float: right !important;
    margin-top: -37px !important;
    text-align: center;
}
.continueyourregistration span {
    font-size: 11px !important;
}
.language-selection {
    margin: 3px 118px !important;
    float: left !important;
}
}
@media only screen and (max-width: 750px){
#menu{
    
    margin-top: -37px;
}
.logo {
    width: 88px;
    padding-top: 5px;
    margin-left: 0px;
}

}


@media only screen and (max-width: 480px){
    
   
   .continueyourregistration {
    margin-right: -25px !important;
       width: 62% !important;
    float: right !important;
    margin-top: -37px !important;
      text-align: center;
}
.logo {
    width: 88px !important;
    padding-top: 5px !important;
    margin-left: -31px !important;
        height: 43px;
}
.continueyourregistration span {
    font-size: 10px !important;
}
   
    .restaurant_panel{
    display:none !important;
}
.language-selection {
    margin: 2px 51px !important;
    float: left !important;
}
    .top-menu-wrapper img.logo-desktop {
   display:none !important;
}
.menu-nav-mobile, .cart-mobile-handle {
    display:none !important;
}
.continueyourregistration {
    width: 100%;
}
.continueyourregistration span {
        font-size: 9px !important;
}
.restaurant_panel {
    width: 100%;
}
.restaurant_panel a {
        font-size: 12px !important;
}
.language-selection{
        float: right;
    margin-top: -37px !important;
}
.join-section--blue-contrast {
    padding: 0px 0 !important;
    height: 532px;
}
#menu{
    
    margin-top: 2px !important;
}
}
@media (max-width: 340px){
.logo {
    width: 88px;
    padding-top: 5px;
    margin-left: -33px;
}
}


@media only screen and (max-width: 240px){
     .join-medium {
    font-size: 13px;
   
}
    .join-xlarge {
    font-size: 19px;
   
}
   .join-content-layout1{
        margin-top: -44px !important;
} 
    .continueyourregistration {
    margin-right: -25px !important;
    width: 62% !important;
    float: right !important;
    margin-top: -50px !important;
      text-align: center;
}
    
.join-h3-new-form {
       font-size: 11px;
    line-height: 14px;
}
.join-section--blue-contrast {
    padding: 0px 0 !important;
    height: 557px;
}
.orange-button.medium, .green-button.medium, .black-button.medium {
    padding: 8px 4px;
}
.form-tabs--inline .form-tabs__button {
    font-size: 12px;
}
.join-table-layout__cell1{
    word-break: break-all;
}

}
   .join-section--blue-contrast {
   background: #001b42;
   overflow: hidden;
   padding: 121px 0;
   position: relative;
   }
   .join-global-scroll-content {
   width: 100%;
   opacity: 1;
   transition: all .7s ease;
   }
   .signup-access{
	 /*  border-radius: 5px;*/
	   background: #fff;
   }
   #main-form-div{
       	display:none;
   }
   #second-form-div{
	display:block;
	z-index: 1;
    right: 120px !important;
    top: 75px;
    position: absolute;
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	border-radius: 5px;
	width: 30%;
   }
   #main-form-div{
       right: 22px !important;
    top: -44px;
    position: absolute;
    border-radius: 5px;
    width: 98%;
   }
   
   
   .signup-access {
    padding: 22px 24px;
    background: #fff;
   }
   @media only screen and (max-width: 600px) {
   #second-form-div{
	right: 0px !important;
    top: 400px;
   }
   .bottom-divs{
	   margin-bottom:157px;
   }
}
 @media only screen and (max-width: 768px) {
   .bottom-divs{
	   margin-bottom:107px;
   }
   .join-table-layout__cell{
	   padding-left:1em !important; 
   }
   .join-content-layout{
	   margin-bottom:100px;
   }
    #second-form-div {
    width: 71% !important;
    right: 85px !important;
    top: 210px !important;
} 
.join-content-layout1{
        margin-top: -56px;
}
#main-form-div {
    right: 0px !important;
    top: 0px !important;
    position: absolute;
    border-radius: 5px;
    width: 100%;
}

}
@media only screen and (max-width: 900px) and (min-width: 768px) {
   .bottom-divs{
	   margin-bottom:107px;
   }
   .join-table-layout__cell{
	   padding-left:1em !important; 
   }
   .join-content-layout{
	   margin-bottom:100px;
   }
    #second-form-div{
	     right: 167px !important;
       top: 232px !important;
    width: 55% !important;
   }
}
@media only screen and (max-width: 600px) {
    #second-form-div{
    right: 0px !important;
    top: 235px !important;
    width: 100% !important;
   }
   .signup-access {
   
    max-width: 100%;
}
}
.signup-access label {
    margin-bottom: 2px;
    margin-left: 15px;
}
@media only screen and (max-width: 240px) {
	.join-content-layout{
	   margin-bottom:20px;
   }
   .view-padding{
		margin-bottom:170px;
	}
	.join-btn--large {
    padding: 12px 5px;
   
}
}
#menu span {
    color: #fff;
    font-family: "Montserrat",sans-serif;
    /* font-family: "Lato","Open Sans",arial; */
   
    font-weight: normal;
    display: block;
    padding: 5px 15px;
    cursor: pointer;
}


</style>
<script>
$(document).ready(function() {
	$('.button1').on('click',function(){
		$('#main-form-div').hide();
		$('#second-form-div').show();
	});
});

$(document).ready(function() {
	$('.button2').on('click',function(){
		$('#main-form-div').show();
		$('#second-form-div').hide();
	});
		$('.continueyourregistration').on('click',function(){
		$('#main-form-div').show();
		$('#second-form-div').hide();
	});
});
 
!function(t){"function"==typeof define&&define.amd?define(["jquery"],function(i){t(i,window,document)}):t(jQuery,window,document)}(function(t,i,e,n){"use strict";var a="intlTelInput",s=1,o={autoFormat:!0,autoHideDialCode:!0,defaultCountry:"",ipinfoToken:"",nationalMode:!0,numberType:"MOBILE",onlyCountries:[],preferredCountries:["us","gb"],preventInvalidNumbers:!1,preventInvalidDialCodes:!1,utilsScript:""},r=38,l=40,u=13,h=27,d=43,c=65,p=90,f=48,g=57,m=32,y=8,v=46,C=17,I=91,_=224,b=!1;function w(i,e){this.element=i,this.options=t.extend({},o,e),this._defaults=o,this.ns="."+a+s++,this.isGoodBrowser=Boolean(i.setSelectionRange),this.hadInitialPlaceholder=Boolean(t(i).attr("placeholder")),this._name=a,this.init()}t(i).load(function(){b=!0}),w.prototype={init:function(){var i=this;if("auto"==this.options.defaultCountry){this.options.defaultCountry="";var e="//ipinfo.io";this.options.ipinfoToken&&(e+="?token="+this.options.ipinfoToken),t.get(e,function(t){t&&t.country&&(i.options.defaultCountry=t.country.toLowerCase())},"jsonp").always(function(){i._ready()})}else this._ready()},_ready:function(){this.options.nationalMode&&(this.options.autoHideDialCode=!1),navigator.userAgent.match(/IEMobile/i)&&(this.options.autoFormat=!1),this._processCountryData(),this._generateMarkup(),this._setInitialState(),this._initListeners()},_processCountryData:function(){this._setInstanceCountryData(),this._setPreferredCountries()},_addCountryCode:function(t,i,e){i in this.countryCodes||(this.countryCodes[i]=[]);var n=e||0;this.countryCodes[i][n]=t},_setInstanceCountryData:function(){var i;if(this.options.onlyCountries.length)for(this.countries=[],i=0;i<D.length;i++)-1!=t.inArray(D[i].iso2,this.options.onlyCountries)&&this.countries.push(D[i]);else this.countries=D;for(this.countryCodes={},this.pcc={},i=0;i<this.countries.length;i++){var e=this.countries[i];if(this._addCountryCode(e.iso2,e.dialCode,e.priority),this._addPotentialCountryCode(e.dialCode,this.pcc,0),e.areaCodes)for(var n=0;n<e.areaCodes.length;n++)this._addCountryCode(e.iso2,e.dialCode+e.areaCodes[n])}},_addPotentialCountryCode:function(t,i,e){var n=t.charAt(e);i[n]||(i[n]=t.length==e+1||{}),t.length>e+1&&this._addPotentialCountryCode(t,i[n],e+1)},_setPreferredCountries:function(){this.preferredCountries=[];for(var t=0;t<this.options.preferredCountries.length;t++){var i=this.options.preferredCountries[t],e=this._getCountryData(i,!1,!0);e&&this.preferredCountries.push(e)}},_generateMarkup:function(){this.telInput=t(this.element),this.telInput.attr("autocomplete","off"),this.telInput.wrap(t("<div>",{class:"intl-tel-input"}));var e=t("<div>",{class:"flag-dropdown"}).insertAfter(this.telInput),n=t("<div>",{class:"selected-flag"}).appendTo(e);this.selectedFlagInner=t("<div>",{class:"iti-flag"}).appendTo(n),t("<div>",{class:"arrow"}).appendTo(this.selectedFlagInner),this.countryList=t("<ul>",{class:"country-list v-hide"}).appendTo(e),this.preferredCountries.length&&(this._appendListItems(this.preferredCountries,"preferred"),t("<li>",{class:"divider"}).appendTo(this.countryList)),this._appendListItems(this.countries,""),this.dropdownHeight=this.countryList.outerHeight(),this.countryList.removeClass("v-hide").addClass("hide"),i.innerWidth<500&&this.countryList.outerWidth(this.telInput.outerWidth()),this.countryListItems=this.countryList.children(".country")},_appendListItems:function(t,i){for(var e="",n=0;n<t.length;n++){var a=t[n];e+="<li class='country "+i+"' data-dial-code='"+a.dialCode+"' data-country-code='"+a.iso2+"'>",e+="<div class='iti-flag "+a.iso2+"'></div>",e+="<span class='country-name'>"+a.name+"</span>",e+="<span class='dial-code'>+"+a.dialCode+"</span>",e+="</li>"}this.countryList.append(e)},_setInitialState:function(){var t=this.telInput.val();this._getDialCode(t)?this._updateFlagFromNumber(t):(this.options.defaultCountry?this.options.defaultCountry=this._getCountryData(this.options.defaultCountry,!1,!1):this.options.defaultCountry=this.preferredCountries.length?this.preferredCountries[0]:this.countries[0],this._selectFlag(this.options.defaultCountry.iso2),t||this._updateDialCode(this.options.defaultCountry.dialCode,!1)),t&&this._updateVal(t,!1)},_initListeners:function(){var e=this;this._initKeyListeners(),(this.options.autoHideDialCode||this.options.autoFormat)&&this._initFocusListeners();var n=this.telInput.closest("label");n.length&&n.on("click"+this.ns,function(t){e.countryList.hasClass("hide")?e.telInput.focus():t.preventDefault()}),this.selectedFlagInner.parent().on("click"+this.ns,function(t){!e.countryList.hasClass("hide")||e.telInput.prop("disabled")||e.telInput.prop("readonly")||e._showDropdown()}),this.options.utilsScript&&(b?this.loadUtils():t(i).load(function(){e.loadUtils()}))},_initKeyListeners:function(){var t=this;this.options.autoFormat&&this.telInput.on("keypress"+this.ns,function(e){if(e.which>=m&&!e.metaKey&&i.intlTelInputUtils&&!t.telInput.prop("readonly")){e.preventDefault();var n=e.which>=f&&e.which<=g||e.which==d,a=t.telInput[0],s=t.isGoodBrowser&&a.selectionStart==a.selectionEnd,o=t.telInput.attr("maxlength"),r=t.telInput.val();if((!o||r.length<o)&&(n||s)){var l=n?String.fromCharCode(e.which):null;t._handleInputKey(l,!0),r!=t.telInput.val()&&t.telInput.trigger("input")}n||t._handleInvalidKey()}}),this.telInput.on("keyup"+this.ns,function(e){if(e.which==u||t.telInput.prop("readonly"));else if(t.options.autoFormat&&i.intlTelInputUtils){var n=e.which==C||e.which==I||e.which==_,a=t.telInput[0],s=t.isGoodBrowser&&a.selectionStart==a.selectionEnd,o=t.isGoodBrowser&&a.selectionStart==t.telInput.val().length;if((e.which==v&&!o||e.which==y||n&&s)&&t._handleInputKey(null,n&&o),!t.options.nationalMode){var r=t.telInput.val();if("+"!=r.substr(0,1)){var l=t.isGoodBrowser?a.selectionStart+1:0;t.telInput.val("+"+r),t.isGoodBrowser&&a.setSelectionRange(l,l)}}}else t._updateFlagFromNumber(t.telInput.val())})},_handleInvalidKey:function(){var t=this;this.telInput.trigger("invalidkey").addClass("iti-invalid-key"),setTimeout(function(){t.telInput.removeClass("iti-invalid-key")},100)},_handleInputKey:function(t,i){var e,n=this.telInput.val(),a=this._getNumeric(n),s=this.telInput[0],o=0;this.isGoodBrowser?(o=this._getDigitsOnRight(n,s.selectionEnd),t?n=n.substr(0,s.selectionStart)+t+n.substring(s.selectionEnd,n.length):e=n.charAt(s.selectionStart-1)):t&&(n+=t);var r=this._getNumeric(n);if(this.options.preventInvalidDialCodes&&"+"==n.charAt(0)&&r.length&&!this._hasPotentialDialCode(r,this.pcc,0))this._handleInvalidKey();else{this.setNumber(n,i),n=this.telInput.val();var l,u=this._getNumeric(n),h=a==u;if(this.options.preventInvalidNumbers&&t&&(h?this._handleInvalidKey():a.length==u.length&&o--),this.isGoodBrowser)o?(l=this._getCursorFromDigitsOnRight(n,o),t||(l=this._getCursorFromLeftChar(n,l,e))):l=n.length,s.setSelectionRange(l,l)}},_hasPotentialDialCode:function(t,i,e){var n=i[t.charAt(e)];return!!n&&(!0===n||("object"==typeof n?t.length==e+1||this._hasPotentialDialCode(t,n,e+1):void 0))},_getCursorFromLeftChar:function(i,e,n){for(var a=e;a>0;a--){var s=i.charAt(a-1);if(s==n||t.isNumeric(s))return a}return 0},_getCursorFromDigitsOnRight:function(i,e){for(var n=i.length-1;n>=0;n--)if(t.isNumeric(i.charAt(n))&&0==--e)return n;return 0},_getDigitsOnRight:function(i,e){for(var n=0,a=e;a<i.length;a++)t.isNumeric(i.charAt(a))&&n++;return n},_initFocusListeners:function(){var t=this;this.options.autoHideDialCode&&this.telInput.on("mousedown"+this.ns,function(i){t.telInput.is(":focus")||t.telInput.val()||(i.preventDefault(),t.telInput.focus())}),this.telInput.on("focus"+this.ns,function(e){var n=t.telInput.val();t.telInput.data("focusVal",n),t.options.autoHideDialCode&&!n&&!t.telInput.prop("readonly")&&t.selectedCountryData.dialCode&&(t._updateVal("+"+t.selectedCountryData.dialCode,!0),t.telInput.one("keypress.plus"+t.ns,function(e){if(e.which==d){var n=t.options.autoFormat&&i.intlTelInputUtils?"+":"";t.telInput.val(n)}}),setTimeout(function(){var i=t.telInput[0];if(t.isGoodBrowser){var e=t.telInput.val().length;i.setSelectionRange(e,e)}}))}),this.telInput.on("blur"+this.ns,function(){if(t.options.autoHideDialCode){var e=t.telInput.val();if("+"==e.substr(0,1)){var n=t._getNumeric(e);n&&t.selectedCountryData.dialCode!=n||t.telInput.val("")}t.telInput.off("keypress.plus"+t.ns)}t.options.autoFormat&&i.intlTelInputUtils&&t.telInput.val()!=t.telInput.data("focusVal")&&t.telInput.trigger("change")})},_getNumeric:function(t){return t.replace(/\D/g,"")},_showDropdown:function(){this._setDropdownPosition();var t=this.countryList.children(".active");t.length&&this._highlightListItem(t),this.countryList.removeClass("hide"),t.length&&this._scrollTo(t),this._bindDropdownListeners(),this.selectedFlagInner.children(".arrow").addClass("up")},_setDropdownPosition:function(){var e=this.telInput.offset().top,n=t(i).scrollTop(),a=e+this.telInput.outerHeight()+this.dropdownHeight<n+t(i).height(),s=e-this.dropdownHeight>n,o=!a&&s?"-"+(this.dropdownHeight-1)+"px":"";this.countryList.css("top",o)},_bindDropdownListeners:function(){var i=this;this.countryList.on("mouseover"+this.ns,".country",function(e){i._highlightListItem(t(this))}),this.countryList.on("click"+this.ns,".country",function(e){i._selectListItem(t(this))});var n=!0;t("html").on("click"+this.ns,function(t){n||i._closeDropdown(),n=!1});var a="",s=null;t(e).on("keydown"+this.ns,function(t){t.preventDefault(),t.which==r||t.which==l?i._handleUpDownKey(t.which):t.which==u?i._handleEnterKey():t.which==h?i._closeDropdown():(t.which>=c&&t.which<=p||t.which==m)&&(s&&clearTimeout(s),a+=String.fromCharCode(t.which),i._searchForCountry(a),s=setTimeout(function(){a=""},1e3))})},_handleUpDownKey:function(t){var i=this.countryList.children(".highlight").first(),e=t==r?i.prev():i.next();e.length&&(e.hasClass("divider")&&(e=t==r?e.prev():e.next()),this._highlightListItem(e),this._scrollTo(e))},_handleEnterKey:function(){var t=this.countryList.children(".highlight").first();t.length&&this._selectListItem(t)},_searchForCountry:function(t){for(var i=0;i<this.countries.length;i++)if(this._startsWith(this.countries[i].name,t)){var e=this.countryList.children("[data-country-code="+this.countries[i].iso2+"]").not(".preferred");this._highlightListItem(e),this._scrollTo(e,!0);break}},_startsWith:function(t,i){return t.substr(0,i.length).toUpperCase()==i},_updateVal:function(t,e){var n;if(this.options.autoFormat&&i.intlTelInputUtils){n=intlTelInputUtils.formatNumber(t,this.selectedCountryData.iso2,e,this.options.preventInvalidNumbers);var a=this.telInput.attr("maxlength");a&&n.length>a&&(n=n.substr(0,a))}else n=t;this.telInput.val(n)},_updateFlagFromNumber:function(i){this.options.nationalMode&&this.selectedCountryData&&"1"==this.selectedCountryData.dialCode&&"+"!=i.substr(0,1)&&(i="+1"+i);var e=this._getDialCode(i);if(e){var n=this.countryCodes[this._getNumeric(e)];if(!(this.selectedCountryData&&-1!=t.inArray(this.selectedCountryData.iso2,n))||this._isUnknownNanp(i,e))for(var a=0;a<n.length;a++)if(n[a]){this._selectFlag(n[a]);break}}else"+"==i.charAt(0)&&(i.length>1?this._selectFlag(""):this.selectedCountryData.iso2||this._selectFlag(this.options.defaultCountry.iso2))},_isUnknownNanp:function(t,i){return"+1"==i&&this._getNumeric(t).length>=4},_highlightListItem:function(t){this.countryListItems.removeClass("highlight"),t.addClass("highlight")},_getCountryData:function(t,i,e){for(var n=i?D:this.countries,a=0;a<n.length;a++)if(n[a].iso2==t)return n[a];if(e)return null;throw new Error("No country data for '"+t+"'")},_selectFlag:function(t){this.selectedCountryData=t?this._getCountryData(t,!1,!1):{},this.selectedFlagInner.attr("class","iti-flag "+t);var i=t?this.selectedCountryData.name+": +"+this.selectedCountryData.dialCode:"Unknown";this.selectedFlagInner.parent().attr("title",i),this._updatePlaceholder(),this.countryListItems.removeClass("active"),t&&this.countryListItems.children(".iti-flag."+t).first().parent().addClass("active")},_updatePlaceholder:function(){if(i.intlTelInputUtils&&!this.hadInitialPlaceholder){var t=this.selectedCountryData.iso2,e=intlTelInputUtils.numberType[this.options.numberType||"FIXED_LINE"],n=t?intlTelInputUtils.getExampleNumber(t,this.options.nationalMode,e):"";this.telInput.attr("placeholder",n)}},_selectListItem:function(t){var i=t.attr("data-country-code");this._selectFlag(i),this._closeDropdown(),this._updateDialCode(t.attr("data-dial-code"),!0),this.telInput.trigger("change"),this.telInput.focus()},_closeDropdown:function(){this.countryList.addClass("hide"),this.selectedFlagInner.children(".arrow").removeClass("up"),t(e).off(this.ns),t("html").off(this.ns),this.countryList.off(this.ns)},_scrollTo:function(t,i){var e=this.countryList,n=e.height(),a=e.offset().top,s=a+n,o=t.outerHeight(),r=t.offset().top,l=r+o,u=r-a+e.scrollTop(),h=n/2-o/2;if(r<a)i&&(u-=h),e.scrollTop(u);else if(l>s){i&&(u+=h);var d=n-o;e.scrollTop(u-d)}},_updateDialCode:function(i,e){var n,a=this.telInput.val();if(i="+"+i,this.options.nationalMode&&"+"!=a.substr(0,1))n=a;else if(a){var s=this._getDialCode(a);if(s.length>1)n=a.replace(s,i);else n=i+("+"!=a.substr(0,1)?t.trim(a):"")}else n=!this.options.autoHideDialCode||e?i:"";this._updateVal(n,e)},_getDialCode:function(i){var e="";if("+"==i.charAt(0))for(var n="",a=0;a<i.length;a++){var s=i.charAt(a);if(t.isNumeric(s)&&(n+=s,this.countryCodes[n]&&(e=i.substr(0,a+1)),4==n.length))break}return e},destroy:function(){this._closeDropdown(),this.telInput.off(this.ns),this.selectedFlagInner.parent().off(this.ns),this.telInput.closest("label").off(this.ns),this.telInput.parent().before(this.telInput).remove()},getNumber:function(t){return i.intlTelInputUtils?intlTelInputUtils.formatNumberByType(this.telInput.val(),this.selectedCountryData.iso2,t):""},getNumberType:function(){return i.intlTelInputUtils?intlTelInputUtils.getNumberType(this.telInput.val(),this.selectedCountryData.iso2):-99},getSelectedCountryData:function(){return this.selectedCountryData||{}},getValidationError:function(){return i.intlTelInputUtils?intlTelInputUtils.getValidationError(this.telInput.val(),this.selectedCountryData.iso2):-99},isValidNumber:function(){var e=t.trim(this.telInput.val()),n=this.options.nationalMode?this.selectedCountryData.iso2:"";return!(/[a-zA-Z]/.test(e)||!i.intlTelInputUtils)&&intlTelInputUtils.isValidNumber(e,n)},loadUtils:function(i){var e=i||this.options.utilsScript;!t.fn[a].loadedUtilsScript&&e&&(t.fn[a].loadedUtilsScript=!0,t.ajax({url:e,success:function(){t(".intl-tel-input input").intlTelInput("utilsLoaded")},dataType:"script",cache:!0}))},selectCountry:function(t){this.selectedFlagInner.hasClass(t)||(this._selectFlag(t),this._updateDialCode(this.selectedCountryData.dialCode,!1))},setNumber:function(t,i){this.options.nationalMode||"+"==t.substr(0,1)||(t="+"+t),this._updateFlagFromNumber(t),this._updateVal(t,i)},utilsLoaded:function(){this.options.autoFormat&&this.telInput.val()&&this._updateVal(this.telInput.val()),this._updatePlaceholder()}},t.fn[a]=function(i){var e,s=arguments;return i===n||"object"==typeof i?this.each(function(){t.data(this,"plugin_"+a)||t.data(this,"plugin_"+a,new w(this,i))}):"string"==typeof i&&"_"!==i[0]&&"init"!==i?(this.each(function(){var n=t.data(this,"plugin_"+a);n instanceof w&&"function"==typeof n[i]&&(e=n[i].apply(n,Array.prototype.slice.call(s,1))),"destroy"===i&&t.data(this,"plugin_"+a,null)}),e!==n?e:this):void 0},t.fn[a].getCountryData=function(){return D};for(var D=[["Afghanistan (‫افغانستان‬‎)","af","93"],["Albania (Shqipëri)","al","355"],["Algeria (‫الجزائر‬‎)","dz","213"],["American Samoa","as","1684"],["Andorra","ad","376"],["Angola","ao","244"],["Anguilla","ai","1264"],["Antigua and Barbuda","ag","1268"],["Argentina","ar","54"],["Armenia (Հայաստան)","am","374"],["Aruba","aw","297"],["Australia","au","61"],["Austria (Österreich)","at","43"],["Azerbaijan (Azərbaycan)","az","994"],["Bahamas","bs","1242"],["Bahrain (‫البحرين‬‎)","bh","973"],["Bangladesh (বাংলাদেশ)","bd","880"],["Barbados","bb","1246"],["Belarus (Беларусь)","by","375"],["Belgium (België)","be","32"],["Belize","bz","501"],["Benin (Bénin)","bj","229"],["Bermuda","bm","1441"],["Bhutan (འབྲུག)","bt","975"],["Bolivia","bo","591"],["Bosnia and Herzegovina (Босна и Херцеговина)","ba","387"],["Botswana","bw","267"],["Brazil (Brasil)","br","55"],["British Indian Ocean Territory","io","246"],["British Virgin Islands","vg","1284"],["Brunei","bn","673"],["Bulgaria (България)","bg","359"],["Burkina Faso","bf","226"],["Burundi (Uburundi)","bi","257"],["Cambodia (កម្ពុជា)","kh","855"],["Cameroon (Cameroun)","cm","237"],["Canada","ca","1",1,["204","226","236","249","250","289","306","343","365","387","403","416","418","431","437","438","450","506","514","519","548","579","581","587","604","613","639","647","672","705","709","742","778","780","782","807","819","825","867","873","902","905"]],["Cape Verde (Kabu Verdi)","cv","238"],["Caribbean Netherlands","bq","599",1],["Cayman Islands","ky","1345"],["Central African Republic (République centrafricaine)","cf","236"],["Chad (Tchad)","td","235"],["Chile","cl","56"],["China (中国)","cn","86"],["Colombia","co","57"],["Comoros (‫جزر القمر‬‎)","km","269"],["Congo (DRC) (Jamhuri ya Kidemokrasia ya Kongo)","cd","243"],["Congo (Republic) (Congo-Brazzaville)","cg","242"],["Cook Islands","ck","682"],["Costa Rica","cr","506"],["Côte d’Ivoire","ci","225"],["Croatia (Hrvatska)","hr","385"],["Cuba","cu","53"],["Curaçao","cw","599",0],["Cyprus (Κύπρος)","cy","357"],["Czech Republic (Česká republika)","cz","420"],["Denmark (Danmark)","dk","45"],["Djibouti","dj","253"],["Dominica","dm","1767"],["Dominican Republic (República Dominicana)","do","1",2,["809","829","849"]],["Ecuador","ec","593"],["Egypt (‫مصر‬‎)","eg","20"],["El Salvador","sv","503"],["Equatorial Guinea (Guinea Ecuatorial)","gq","240"],["Eritrea","er","291"],["Estonia (Eesti)","ee","372"],["Ethiopia","et","251"],["Falkland Islands (Islas Malvinas)","fk","500"],["Faroe Islands (Føroyar)","fo","298"],["Fiji","fj","679"],["Finland (Suomi)","fi","358"],["France","fr","33"],["French Guiana (Guyane française)","gf","594"],["French Polynesia (Polynésie française)","pf","689"],["Gabon","ga","241"],["Gambia","gm","220"],["Georgia (საქართველო)","ge","995"],["Germany (Deutschland)","de","49"],["Ghana (Gaana)","gh","233"],["Gibraltar","gi","350"],["Greece (Ελλάδα)","gr","30"],["Greenland (Kalaallit Nunaat)","gl","299"],["Grenada","gd","1473"],["Guadeloupe","gp","590",0],["Guam","gu","1671"],["Guatemala","gt","502"],["Guinea (Guinée)","gn","224"],["Guinea-Bissau (Guiné Bissau)","gw","245"],["Guyana","gy","592"],["Haiti","ht","509"],["Honduras","hn","504"],["Hong Kong (香港)","hk","852"],["Hungary (Magyarország)","hu","36"],["Iceland (Ísland)","is","354"],["India (भारत)","in","91"],["Indonesia","id","62"],["Iran (‫ایران‬‎)","ir","98"],["Iraq (‫العراق‬‎)","iq","964"],["Ireland","ie","353"],["Israel (‫ישראל‬‎)","il","972"],["Italy (Italia)","it","39",0],["Jamaica","jm","1876"],["Japan (日本)","jp","81"],["Jordan (‫الأردن‬‎)","jo","962"],["Kazakhstan (Казахстан)","kz","7",1],["Kenya","ke","254"],["Kiribati","ki","686"],["Kuwait (‫الكويت‬‎)","kw","965"],["Kyrgyzstan (Кыргызстан)","kg","996"],["Laos (ລາວ)","la","856"],["Latvia (Latvija)","lv","371"],["Lebanon (‫لبنان‬‎)","lb","961"],["Lesotho","ls","266"],["Liberia","lr","231"],["Libya (‫ليبيا‬‎)","ly","218"],["Liechtenstein","li","423"],["Lithuania (Lietuva)","lt","370"],["Luxembourg","lu","352"],["Macau (澳門)","mo","853"],["Macedonia (FYROM) (Македонија)","mk","389"],["Madagascar (Madagasikara)","mg","261"],["Malawi","mw","265"],["Malaysia","my","60"],["Maldives","mv","960"],["Mali","ml","223"],["Malta","mt","356"],["Marshall Islands","mh","692"],["Martinique","mq","596"],["Mauritania (‫موريتانيا‬‎)","mr","222"],["Mauritius (Moris)","mu","230"],["Mexico (México)","mx","52"],["Micronesia","fm","691"],["Moldova (Republica Moldova)","md","373"],["Monaco","mc","377"],["Mongolia (Монгол)","mn","976"],["Montenegro (Crna Gora)","me","382"],["Montserrat","ms","1664"],["Morocco (‫المغرب‬‎)","ma","212"],["Mozambique (Moçambique)","mz","258"],["Myanmar (Burma) (မြန်မာ)","mm","95"],["Namibia (Namibië)","na","264"],["Nauru","nr","674"],["Nepal (नेपाल)","np","977"],["Netherlands (Nederland)","nl","31"],["New Caledonia (Nouvelle-Calédonie)","nc","687"],["New Zealand","nz","64"],["Nicaragua","ni","505"],["Niger (Nijar)","ne","227"],["Nigeria","ng","234"],["Niue","nu","683"],["Norfolk Island","nf","672"],["North Korea (조선 민주주의 인민 공화국)","kp","850"],["Northern Mariana Islands","mp","1670"],["Norway (Norge)","no","47"],["Oman (‫عُمان‬‎)","om","968"],["Pakistan (‫پاکستان‬‎)","pk","92"],["Palau","pw","680"],["Palestine (‫فلسطين‬‎)","ps","970"],["Panama (Panamá)","pa","507"],["Papua New Guinea","pg","675"],["Paraguay","py","595"],["Peru (Perú)","pe","51"],["Philippines","ph","63"],["Poland (Polska)","pl","48"],["Portugal","pt","351"],["Puerto Rico","pr","1",3,["787","939"]],["Qatar (‫قطر‬‎)","qa","974"],["Réunion (La Réunion)","re","262"],["Romania (România)","ro","40"],["Russia (Россия)","ru","7",0],["Rwanda","rw","250"],["Saint Barthélemy (Saint-Barthélemy)","bl","590",1],["Saint Helena","sh","290"],["Saint Kitts and Nevis","kn","1869"],["Saint Lucia","lc","1758"],["Saint Martin (Saint-Martin (partie française))","mf","590",2],["Saint Pierre and Miquelon (Saint-Pierre-et-Miquelon)","pm","508"],["Saint Vincent and the Grenadines","vc","1784"],["Samoa","ws","685"],["San Marino","sm","378"],["São Tomé and Príncipe (São Tomé e Príncipe)","st","239"],["Saudi Arabia (‫المملكة العربية السعودية‬‎)","sa","966"],["Senegal (Sénégal)","sn","221"],["Serbia (Србија)","rs","381"],["Seychelles","sc","248"],["Sierra Leone","sl","232"],["Singapore","sg","65"],["Sint Maarten","sx","1721"],["Slovakia (Slovensko)","sk","421"],["Slovenia (Slovenija)","si","386"],["Solomon Islands","sb","677"],["Somalia (Soomaaliya)","so","252"],["South Africa","za","27"],["South Korea (대한민국)","kr","82"],["South Sudan (‫جنوب السودان‬‎)","ss","211"],["Spain (España)","es","34"],["Sri Lanka (ශ්‍රී ලංකාව)","lk","94"],["Sudan (‫السودان‬‎)","sd","249"],["Suriname","sr","597"],["Swaziland","sz","268"],["Sweden (Sverige)","se","46"],["Switzerland (Schweiz)","ch","41"],["Syria (‫سوريا‬‎)","sy","963"],["Taiwan (台灣)","tw","886"],["Tajikistan","tj","992"],["Tanzania","tz","255"],["Thailand (ไทย)","th","66"],["Timor-Leste","tl","670"],["Togo","tg","228"],["Tokelau","tk","690"],["Tonga","to","676"],["Trinidad and Tobago","tt","1868"],["Tunisia (‫تونس‬‎)","tn","216"],["Turkey (Türkiye)","tr","90"],["Turkmenistan","tm","993"],["Turks and Caicos Islands","tc","1649"],["Tuvalu","tv","688"],["U.S. Virgin Islands","vi","1340"],["Uganda","ug","256"],["Ukraine (Україна)","ua","380"],["United Arab Emirates (‫الإمارات العربية المتحدة‬‎)","ae","971"],["United Kingdom","gb","44"],["United States","us","1",0],["Uruguay","uy","598"],["Uzbekistan (Oʻzbekiston)","uz","998"],["Vanuatu","vu","678"],["Vatican City (Città del Vaticano)","va","39",1],["Venezuela","ve","58"],["Vietnam (Việt Nam)","vn","84"],["Wallis and Futuna","wf","681"],["Yemen (‫اليمن‬‎)","ye","967"],["Zambia","zm","260"],["Zimbabwe","zw","263"]],k=0;k<D.length;k++){var S=D[k];D[k]={name:S[0],iso2:S[1],dialCode:S[2],priority:S[3]||0,areaCodes:S[4]||null}}}),$("#telephone").intlTelInput({nationalMode:!1,preventInvalidDialCodes:!0});     
</script>