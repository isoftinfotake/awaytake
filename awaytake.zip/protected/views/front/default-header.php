
<div class="mobile-banner-wrap relative">
 <div class="layer"></div>
 <img class="mobile-banner" src="<?php echo assetsURL()."/images/banner-5-mobile.jpg"?>">
</div>

<div  id="parallax-wrap" class="parallax-search" 
data-parallax="scroll" data-position="center" data-bleed="10" 
data-image-src="<?php echo assetsURL()."/images/banner-5.jpg"?>">

<div class="search-wraps">
	<h1><?php echo isset($h1)?$h1:''?></h1>
	<p><?php echo isset($sub_text)?$sub_text:''?></p>
</div> <!--search-wraps-->

</div> <!--parallax-container-->